import React from 'react'
import './footer.css'

const Footer = () => {
  return (
    <div>
      footer
    </div>
  )
}

export default Footer
