import React from 'react'
import './About'

const About = () => {
  return (
    <div>
      about
    </div>
  )
}

export default About
