import React from 'react'
import './contact.css'

const Contact = () => {
  return (
    <div>
      contact
    </div>
  )
}

export default Contact
