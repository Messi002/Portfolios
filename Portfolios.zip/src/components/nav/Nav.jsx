import React from 'react'
import './nav.css'

const Nav = () => {
  return (
    <div>
      navbar
    </div>
  )
}

export default Nav
